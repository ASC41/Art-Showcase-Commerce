import './framer/styles.css'

import GalleryXFramerComponent from './framer/gallery-x'

export default function App() {
  return (
    <div className='flex flex-col items-center gap-3 bg-[white]'>
      <GalleryXFramerComponent.Responsive />
    </div>
  );
};